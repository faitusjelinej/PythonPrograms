import math_operations

first = int(input("Enter the first number: "))
second = int(input("Enter the second number: "))

result = math_operations.addition_cl.add_fn(first,second)
print(result)

result = math_operations.subtract_cl.subtract_fn(first,second)
print(result)