class addition_cl():
    def __init__(self,a,b):
        self.a = a
        self.b = b
    def add_fn(a,b):
        return a+b
