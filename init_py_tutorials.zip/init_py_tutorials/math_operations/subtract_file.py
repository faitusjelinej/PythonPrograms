class subtract_cl():
    def __init__(self,a,b):
        self.a = a
        self.b = b
    def subtract_fn(a,b):
        return a-b
